using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace zharptitsa.Pages
{
    /// <summary>
    /// Страница авторизации пользователя.
    /// Позволяет войти в систему по логину и паролю из базы данных
    /// или продолжить работу в качестве гостя.
    /// </summary>
    public partial class AuthPage : Page
    {
        public AuthPage()
        {
            InitializeComponent();
            AppWindow.FrameTitle = "Авторизация";
        }

        /// <summary>
        /// Обработчик кнопки входа в систему.
        /// Проверяет логин и пароль по базе данных.
        /// При успехе сохраняет текущего пользователя и переходит на главную страницу.
        /// </summary>
        private void ButtonLogin_Click(object sender, RoutedEventArgs e)
        {
            var user = Entities.GetContext().User.FirstOrDefault(u => u.Login == TextBoxLogin.Text.Trim() && u.Password == PasswordBoxPassword.Password.Trim());
            if (user != null)
            {
                User.currentUser = user;
                MessageBox.Show($"Здравствуйте, {user.FullName}!", "Добро пожаловать!", MessageBoxButton.OK, MessageBoxImage.Information);
                NavigationService.Navigate(new MainPage());
            }
            else
            {
                MessageBox.Show("Пользователь с такими данными не найден", "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Обработчик кнопки входа в качестве гостя.
        /// Сбрасывает текущего пользователя и переходит на главную страницу с ограниченным доступом.
        /// </summary>
        private void ButtonGuestLogin_Click(object sender, RoutedEventArgs e)
        {
            User.currentUser = null;
            NavigationService.Navigate(new MainPage());
        }
    }
}
