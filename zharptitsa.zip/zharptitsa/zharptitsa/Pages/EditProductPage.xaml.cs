using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace zharptitsa.Pages
{
    public partial class EditProductPage : Page
    {
        private string _newImagePath;
        private string _oldImagePath;
        private bool _isEditing;

        public EditProductPage(Product product = null)
        {
            InitializeComponent();
            AppWindow.FrameTitle = product == null ? "Добавление продукции" : "Редактирование продукции";

            MainPage._isEditPageOpen = true;

            var productTypes = Entities.GetContext().ProductType.ToList();
            ComboBoxProductType.ItemsSource = productTypes;

            if (product != null)
            {
                _oldImagePath = product.Image;
                _isEditing = true;
                CheckBoxDiscountActive.IsChecked = product.IsDiscountActive == 1;
                StackPanelId.Visibility = Visibility.Visible;
                ButtonDelete.Visibility = Visibility.Visible;
            }
            else
            {
                product = new Product() { Product_id = productTypes.FirstOrDefault()?.id ?? 0, IsDiscountActive = 0 };
                StackPanelId.Visibility = Visibility.Collapsed;
                ButtonDelete.Visibility = Visibility.Collapsed;
            }

            DataContext = product;
        }

        private void ButtonSelectPhoto_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog { Filter = "Image|*.jpg;*.png" };

            if (dlg.ShowDialog() == true)
            {
                using (var img = System.Drawing.Image.FromFile(dlg.FileName))
                {
                    if (img.Width > 300 || img.Height > 200)
                    {
                        MessageBox.Show($"Фото слишком большое! Максимум 300x200. Сейчас: {img.Width}x{img.Height}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }

                _newImagePath = dlg.FileName;
                var currentProduct = (Product)DataContext;
                currentProduct.Image = _newImagePath;
                DataContext = null;
                DataContext = currentProduct;
            }
        }

        private void ButtonSave_Click(object sender, RoutedEventArgs e)
        {
            var currentProduct = (Product)DataContext;
            List<string> errors = new List<string>();

            if (string.IsNullOrWhiteSpace(TextBoxName.Text)) errors.Add("Имя продукта не может быть пустым");
            if (!decimal.TryParse(TextBoxPrice.Text.Replace('.', ','), out decimal price) || price < 0) errors.Add("Стоимость должна быть числом >= 0");
            if (!int.TryParse(TextBoxDiscount.Text, out int discount) || discount < 0 || discount > 100) errors.Add("Скидка должна быть от 0 до 100");
            if (!int.TryParse(TextBoxMinStock.Text, out int minStock) || minStock < 0) errors.Add("Минимальный остаток должен быть >= 0");
            if (ComboBoxProductType.SelectedValue == null) errors.Add("Выберите тип продукции");

            if (errors.Any())
            {
                MessageBox.Show(string.Join("\n", errors), "Поля не заполнены корректно", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            currentProduct.DiscountProcent = discount;
            currentProduct.Price = price;
            currentProduct.MinStock = minStock;
            currentProduct.IsDiscountActive = CheckBoxDiscountActive.IsChecked == true ? 1 : 0;

            if (!_isEditing)
                Entities.GetContext().Product.Add(currentProduct);

            if (!string.IsNullOrEmpty(_newImagePath))
            {
                string productsFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "products");
                if (!Directory.Exists(productsFolder))
                    Directory.CreateDirectory(productsFolder);

                string fileName = $"product_{Guid.NewGuid()}.jpg";
                string fullPath = Path.Combine(productsFolder, fileName);

                using (var img = System.Drawing.Image.FromFile(_newImagePath))
                    img.Save(fullPath, System.Drawing.Imaging.ImageFormat.Jpeg);

                if (!string.IsNullOrWhiteSpace(_oldImagePath))
                {
                    string oldFullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, _oldImagePath.TrimStart('\\'));
                    if (File.Exists(oldFullPath))
                        File.Delete(oldFullPath);
                }

                currentProduct.Image = $"\\products\\{fileName}";
            }

            try
            {
                Entities.GetContext().SaveChanges();
                NavigationService.GoBack();
            }
            catch (DataException ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            var currentProduct = (Product)DataContext;
            if (MessageBox.Show($"Удалить продукт \"{currentProduct.ProductName}\"?", "Удаление", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    var context = Entities.GetContext();
                    context.Product.Remove(currentProduct);
                    context.SaveChanges();

                    if (!string.IsNullOrWhiteSpace(_oldImagePath))
                    {
                        string oldFullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, _oldImagePath.TrimStart('\\'));
                        if (File.Exists(oldFullPath))
                            File.Delete(oldFullPath);
                    }

                    NavigationService.GoBack();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при удалении: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
