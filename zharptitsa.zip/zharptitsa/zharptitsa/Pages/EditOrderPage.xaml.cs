using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace zharptitsa.Pages
{
    public partial class EditOrderPage : Page
    {
        private bool _isEditing;

        public EditOrderPage(Order order = null)
        {
            InitializeComponent();
            AppWindow.FrameTitle = order == null ? "Добавление заказа" : "Редактирование заказа";

            var statuses = Entities.GetContext().Status.ToList();
            ComboBoxStatus.ItemsSource = statuses;

            if (order != null)
            {
                _isEditing = true;
            }
            else
            {
                order = new Order() { Status_Id = 1, OrderDate = DateTime.Now, DeliveryDate = DateTime.Now.AddDays(7) };
            }

            DataContext = order;
        }

        private void ButtonSave_Click(object sender, RoutedEventArgs e)
        {
            var currentOrder = (Order)DataContext;
            List<string> errors = new List<string>();

            if (string.IsNullOrWhiteSpace(TextBoxAddress.Text)) errors.Add("Адрес доставки не может быть пустым");
            if (!decimal.TryParse(TextBoxPrice.Text.Replace('.', ','), out decimal price) || price < 0) errors.Add("Стоимость должна быть числом >= 0");
            if (!DateTime.TryParse(TextBoxDeliveryDate.Text, out DateTime deliveryDate)) errors.Add("Неверный формат даты доставки (ГГГГ-ММ-ДД)");
            if (ComboBoxStatus.SelectedValue == null) errors.Add("Выберите статус заказа");

            if (errors.Any())
            {
                MessageBox.Show(string.Join("\n", errors), "Поля не заполнены корректно", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            currentOrder.PriceOrder = price;
            currentOrder.DeliveryDate = deliveryDate;

            if (!_isEditing)
                Entities.GetContext().Order.Add(currentOrder);

            try
            {
                Entities.GetContext().SaveChanges();
                NavigationService.GoBack();
            }
            catch (DataException ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
