using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace zharptitsa.Pages
{
    public partial class OrdersPage : Page
    {
        public OrdersPage()
        {
            InitializeComponent();
            AppWindow.FrameTitle = "Заказы";

            if (User.currentUser?.Role_id == 1)
            {
                ButtonAdd.Visibility = Visibility.Visible;
                ButtonDelete.Visibility = Visibility.Visible;
            }
        }

        private void LoadOrders()
        {
            StackPanelOrders.Children.Clear();
            var orders = Entities.GetContext().Order.ToList();

            foreach (var order in orders)
            {
                StackPanelOrders.Children.Add(CreateOrderCard(order));
            }
        }

        private Border CreateOrderCard(Order order)
        {
            var border = new Border
            {
                CornerRadius = new CornerRadius(10),
                BorderBrush = Brushes.LightGray,
                BorderThickness = new Thickness(1),
                Margin = new Thickness(10),
                Padding = new Thickness(15),
                Background = Brushes.White,
                Tag = order
            };

            var mainGrid = new Grid();
            mainGrid.ColumnDefinitions.Add(new ColumnDefinition());
            mainGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var infoStack = new StackPanel();
            infoStack.Children.Add(new TextBlock { Text = $"Артикул заказа: {order.id}", FontWeight = FontWeights.Bold, FontSize = 15, Margin = new Thickness(0, 0, 0, 3) });
            infoStack.Children.Add(new TextBlock { Text = $"Статус заказа: {order.Status?.StatusName ?? "Не указан"}", FontSize = 13, Margin = new Thickness(0, 0, 0, 3) });
            infoStack.Children.Add(new TextBlock { Text = $"Товары: {order.ProductName}", FontSize = 13, Margin = new Thickness(0, 0, 0, 3), TextWrapping = TextWrapping.Wrap });
            infoStack.Children.Add(new TextBlock { Text = $"Адрес пункта выдачи: {order.AdressDelivery}", FontSize = 13, Margin = new Thickness(0, 0, 0, 3) });
            infoStack.Children.Add(new TextBlock { Text = $"Дата заказа: {order.OrderDate:dd.MM.yyyy}", FontSize = 13 });
            infoStack.Children.Add(new TextBlock { Text = $"Сумма: {order.PriceOrder:N2} ₽", FontSize = 13, FontWeight = FontWeights.Bold });
            Grid.SetColumn(infoStack, 0);
            mainGrid.Children.Add(infoStack);

            var deliveryBorder = new Border
            {
                BorderBrush = Brushes.Black,
                BorderThickness = new Thickness(1),
                Padding = new Thickness(15),
                Margin = new Thickness(15, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            deliveryBorder.Child = new TextBlock
            {
                Text = $"Дата доставки:\n{order.DeliveryDate:dd.MM.yyyy}",
                FontSize = 13,
                TextAlignment = TextAlignment.Center,
                TextWrapping = TextWrapping.Wrap
            };
            Grid.SetColumn(deliveryBorder, 1);
            mainGrid.Children.Add(deliveryBorder);

            border.Child = mainGrid;
            return border;
        }

        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new EditOrderPage(null as Order));
        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            if (StackPanelOrders.Children.Count == 0)
            {
                MessageBox.Show("Нет заказов для удаления", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (MessageBox.Show("Удаление заказов пока не реализовано", "Внимание", MessageBoxButton.OK, MessageBoxImage.Information) == MessageBoxResult.OK)
            {
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e) => LoadOrders();
    }
}
