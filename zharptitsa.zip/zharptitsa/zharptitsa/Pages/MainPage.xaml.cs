using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;

namespace zharptitsa.Pages
{
    public partial class MainPage : Page
    {
        public static bool _isEditPageOpen = false;
        private Product _selectedProduct = null;
        private Border _selectedBorder = null;

        public MainPage()
        {
            InitializeComponent();
            AppWindow.FrameTitle = "Главная страница";

            var roleName = User.currentUser?.Role?.Name?.Trim().ToLower();

            if (User.currentUser != null)
            {
                ButtonAuth.Content = "Выход";
                switch (roleName)
                {
                    case "администратор":
                        ButtonAdd.Visibility = Visibility.Visible;
                        ButtonDelete.Visibility = Visibility.Visible;
                        ButtonOrders.Visibility = Visibility.Visible;
                        ButtonCart.Visibility = Visibility.Visible;
                        break;
                    case "менеджер":
                        ButtonOrders.Visibility = Visibility.Visible;
                        ButtonCart.Visibility = Visibility.Visible;
                        break;
                    case "пользователь":
                        ButtonCart.Visibility = Visibility.Visible;
                        break;
                }
            }
            else
            {
                ButtonCart.Visibility = Visibility.Collapsed;
            }
        }

        private void LoadProducts()
        {
            WrapPanelProducts.Children.Clear();
            var productsQuery = Entities.GetContext().Product.ToList();

            var search = TextBoxSearch?.Text?.Trim().ToLower();

            if (!string.IsNullOrWhiteSpace(search))
                productsQuery = productsQuery.Where(p => p.ProductName.ToLower().Contains(search) || (p.Description != null && p.Description.ToLower().Contains(search)) || (p.Composition != null && p.Composition.ToLower().Contains(search))).ToList();

            if (ComboBoxFilter?.SelectedItem is ProductType productType && productType.id != 0)
                productsQuery = productsQuery.Where(p => p.Product_id == productType.id).ToList();

            switch (ComboBoxSort.SelectedIndex)
            {
                case 1:
                    productsQuery = productsQuery.OrderBy(p => p.Price).ToList();
                    break;
                case 2:
                    productsQuery = productsQuery.OrderByDescending(p => p.Price).ToList();
                    break;
            }

            foreach (var product in productsQuery)
            {
                WrapPanelProducts.Children.Add(CreateProductCard(product));
            }
        }

        private Border CreateProductCard(Product product)
        {
            bool isDiscounted = product.IsDiscountActive == 1 && product.DiscountProcent > 10;
            string cardBg = isDiscounted ? "#BB5FCA" : "White";
            string cardBorder = isDiscounted ? "#BB5FCA" : "#DDDDDD";

            var roleName = User.currentUser?.Role?.Name?.Trim().ToLower();
            bool canAddToCart = User.currentUser != null && roleName != null;

            var border = new Border
            {
                Width = 320,
                Height = 400,
                Margin = new Thickness(10),
                CornerRadius = new CornerRadius(12),
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString(cardBg)),
                BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(cardBorder)),
                BorderThickness = new Thickness(1),
                Tag = product,
                Cursor = System.Windows.Input.Cursors.Hand
            };
            border.MouseLeftButtonDown += Border_MouseLeftButtonDown;
            border.MouseLeftButtonUp += Border_MouseLeftButtonUp;

            var mainGrid = new Grid();
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // Row 0: Type + Discount badge
            var topGrid = new Grid { Margin = new Thickness(15, 10, 15, 5) };
            topGrid.Children.Add(new TextBlock
            {
                Text = product.ProductType?.ProductType1 ?? "",
                Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#67BA80")),
                FontWeight = FontWeights.SemiBold,
                FontSize = 13,
                VerticalAlignment = VerticalAlignment.Center
            });

            if (product.IsDiscountActive == 1 && product.DiscountProcent > 0)
            {
                var discountBadge = new Border
                {
                    Background = new SolidColorBrush(Colors.Orange),
                    CornerRadius = new CornerRadius(6),
                    Padding = new Thickness(10, 3, 10, 3),
                    HorizontalAlignment = HorizontalAlignment.Right
                };
                discountBadge.Child = new TextBlock { Text = $"-{product.DiscountProcent}%", Foreground = Brushes.White, FontWeight = FontWeights.Bold, FontSize = 13 };
                topGrid.Children.Add(discountBadge);
            }
            Grid.SetRow(topGrid, 0);
            mainGrid.Children.Add(topGrid);

            // Row 1: Name
            var textBlockName = new TextBlock
            {
                Text = product.ProductName,
                FontWeight = FontWeights.Bold,
                FontSize = 17,
                Foreground = isDiscounted ? Brushes.White : Brushes.Black,
                Margin = new Thickness(15, 0, 15, 3)
            };
            Grid.SetRow(textBlockName, 1);
            mainGrid.Children.Add(textBlockName);

            // Row 2: Composition
            var textBlockComposition = new TextBlock
            {
                Text = "Состав: " + (string.IsNullOrWhiteSpace(product.Composition) ? "Не указан" : product.Composition),
                FontSize = 11,
                Margin = new Thickness(15, 0, 15, 5),
                TextWrapping = TextWrapping.Wrap,
                Foreground = isDiscounted ? new SolidColorBrush(Color.FromArgb(180, 255, 255, 255)) : Brushes.Gray,
                MaxHeight = 45
            };
            Grid.SetRow(textBlockComposition, 2);
            mainGrid.Children.Add(textBlockComposition);

            // Row 3: Image
            var imageContainer = new Grid { Margin = new Thickness(15, 5, 15, 5) };
            try
            {
                imageContainer.Children.Add(new Image
                {
                    Source = new BitmapImage(new Uri(product.ProductPhoto, UriKind.RelativeOrAbsolute)),
                    MaxHeight = 100,
                    MaxWidth = 180,
                    Stretch = Stretch.Uniform,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                });
            }
            catch { }
            Grid.SetRow(imageContainer, 3);
            mainGrid.Children.Add(imageContainer);

            // Row 4: Separator
            var separator = new Rectangle { Height = 1, Fill = isDiscounted ? new SolidColorBrush(Color.FromArgb(80, 255, 255, 255)) : Brushes.LightGray, Margin = new Thickness(15, 0, 15, 0) };
            Grid.SetRow(separator, 4);
            mainGrid.Children.Add(separator);

            // Row 5: Price + Cart button
            var priceGrid = new Grid { Margin = new Thickness(15, 5, 15, 10) };
            priceGrid.ColumnDefinitions.Add(new ColumnDefinition());
            priceGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            priceGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            priceGrid.Children.Add(new TextBlock { Text = "Стоимость", VerticalAlignment = VerticalAlignment.Center, FontSize = 13, Foreground = isDiscounted ? Brushes.White : Brushes.Black });

            if (canAddToCart)
            {
                var buttonAddToCart = new Button
                {
                    Content = "В корзину",
                    Margin = new Thickness(5, 0, 5, 0),
                    Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#67BA80")),
                    Foreground = Brushes.White,
                    BorderThickness = new Thickness(0),
                    Height = 28,
                    Padding = new Thickness(8, 0, 8, 0),
                    Tag = product,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                };
                buttonAddToCart.Click += ButtonAddToCart_Click;
                Grid.SetColumn(buttonAddToCart, 1);
                priceGrid.Children.Add(buttonAddToCart);
            }

            var priceBorder = new Border
            {
                Background = isDiscounted ? new SolidColorBrush(Color.FromArgb(80, 255, 255, 255)) : Brushes.Transparent,
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(8, 2, 8, 2),
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Center
            };
            priceBorder.Child = new TextBlock
            {
                Text = $"{product.Price:N2} ₽",
                Foreground = isDiscounted ? Brushes.White : new SolidColorBrush((Color)ColorConverter.ConvertFromString("#67BA80")),
                FontWeight = FontWeights.Bold,
                FontSize = 16
            };
            Grid.SetColumn(priceBorder, 2);
            priceGrid.Children.Add(priceBorder);

            Grid.SetRow(priceGrid, 5);
            mainGrid.Children.Add(priceGrid);

            border.Child = mainGrid;
            return border;
        }

        private void TextBoxSearch_TextChanged(object sender, TextChangedEventArgs e) => LoadProducts();

        private void ComboBoxSort_SelectionChanged(object sender, SelectionChangedEventArgs e) => LoadProducts();

        private void ComboBoxFilter_SelectionChanged(object sender, SelectionChangedEventArgs e) => LoadProducts();

        private void ButtonCart_Click(object sender, RoutedEventArgs e) => NavigationService.Navigate(new CartPage());

        private void ButtonAuth_Click(object sender, RoutedEventArgs e)
        {
            if (User.currentUser != null)
            {
                User.currentUser = null;
                NavigationService.Navigate(new MainPage());
            }
            else
            {
                NavigationService.Navigate(new AuthPage());
            }
        }

        private void ButtonOrders_Click(object sender, RoutedEventArgs e) => NavigationService.Navigate(new OrdersPage());

        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            var roleName = User.currentUser?.Role?.Name?.Trim().ToLower();
            if (roleName == "администратор")
            {
                if (_isEditPageOpen)
                {
                    MessageBox.Show("Окно редактирования уже открыто. Закройте его перед открытием нового.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                NavigationService.Navigate(new EditProductPage(null as Product));
            }
        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedProduct == null)
            {
                MessageBox.Show("Выберите продукт для удаления", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var roleName = User.currentUser?.Role?.Name?.Trim().ToLower();
            if (roleName != "администратор")
            {
                MessageBox.Show("Удаление доступно только администратору", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (MessageBox.Show($"Удалить продукт \"{_selectedProduct.ProductName}\"?", "Удаление", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    var context = Entities.GetContext();
                    context.Product.Remove(_selectedProduct);
                    context.SaveChanges();
                    _selectedProduct = null;
                    _selectedBorder = null;
                    ButtonDelete.IsEnabled = false;
                    LoadProducts();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при удалении: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void Border_MouseLeftButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var roleName = User.currentUser?.Role?.Name?.Trim().ToLower();
            if (roleName == "администратор")
            {
                var border = sender as Border;
                var product = border?.Tag as Product;
                if (product != null)
                {
                    if (_selectedBorder != null)
                        _selectedBorder.BorderThickness = new Thickness(1);

                    _selectedProduct = product;
                    _selectedBorder = border;
                    border.BorderThickness = new Thickness(3);
                    border.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#67BA80"));
                    ButtonDelete.IsEnabled = true;
                }
            }
        }

        private void Border_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var roleName = User.currentUser?.Role?.Name?.Trim().ToLower();
            if (roleName == "администратор" && e.ClickCount == 2)
            {
                var border = sender as Border;
                var product = border?.Tag as Product;
                if (product != null)
                {
                    if (_isEditPageOpen)
                    {
                        MessageBox.Show("Окно редактирования уже открыто", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }
                    NavigationService.Navigate(new EditProductPage(product));
                }
            }
        }

        private void ButtonAddToCart_Click(object sender, RoutedEventArgs e)
        {
            var product = (sender as Button)?.Tag as Product;
            if (product != null)
            {
                CartPage.cart.Add(product);
                MessageBox.Show($"\"{product.ProductName}\" добавлен в корзину", "Корзина", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            _isEditPageOpen = false;
            _selectedProduct = null;
            _selectedBorder = null;
            ButtonDelete.IsEnabled = false;
            var productTypes = Entities.GetContext().ProductType.ToList();
            productTypes.Insert(0, new ProductType { id = 0, ProductType1 = "Все типы" });
            ComboBoxFilter.ItemsSource = productTypes;
            ComboBoxFilter.SelectedIndex = 0;
            ComboBoxSort.SelectedIndex = 0;
            LoadProducts();
        }
    }
}
