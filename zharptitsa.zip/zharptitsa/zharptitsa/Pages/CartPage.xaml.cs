using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace zharptitsa.Pages
{
    public partial class CartPage : Page
    {
        public static List<Product> cart = new List<Product>();

        public CartPage()
        {
            InitializeComponent();
            AppWindow.FrameTitle = "Корзина";
        }

        private void Page_Loaded(object sender, RoutedEventArgs e) => LoadCart();

        private void LoadCart()
        {
            WrapPanelCart.Children.Clear();
            foreach (var product in cart)
            {
                WrapPanelCart.Children.Add(CreateCartCard(product));
            }
        }

        private Border CreateCartCard(Product product)
        {
            bool isDiscounted = product.IsDiscountActive == 1 && product.DiscountProcent > 10;
            string cardBg = isDiscounted ? "#BB5FCA" : "White";

            var border = new Border
            {
                Width = 320,
                Height = 400,
                Margin = new Thickness(10),
                CornerRadius = new CornerRadius(12),
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString(cardBg)),
                BorderBrush = isDiscounted ? new SolidColorBrush((Color)ColorConverter.ConvertFromString("#BB5FCA")) : Brushes.LightGray,
                BorderThickness = new Thickness(1)
            };

            var mainGrid = new Grid();
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var topGrid = new Grid { Margin = new Thickness(15, 12, 15, 0) };
            topGrid.Children.Add(new TextBlock
            {
                Text = product.ProductName,
                FontWeight = FontWeights.Bold,
                FontSize = 17,
                Foreground = isDiscounted ? Brushes.White : Brushes.Black,
                VerticalAlignment = VerticalAlignment.Center
            });

            if (product.IsDiscountActive == 1 && product.DiscountProcent > 0)
            {
                var badge = new Border
                {
                    Background = Brushes.Orange,
                    CornerRadius = new CornerRadius(6),
                    Padding = new Thickness(10, 3, 10, 3),
                    HorizontalAlignment = HorizontalAlignment.Right
                };
                badge.Child = new TextBlock { Text = $"-{product.DiscountProcent}%", Foreground = Brushes.White, FontWeight = FontWeights.Bold, FontSize = 13 };
                topGrid.Children.Add(badge);
            }
            Grid.SetRow(topGrid, 0);
            mainGrid.Children.Add(topGrid);

            var compositionText = new TextBlock
            {
                Text = "Состав: " + (string.IsNullOrWhiteSpace(product.Composition) ? "Не указан" : product.Composition),
                FontSize = 11,
                Margin = new Thickness(15, 3, 15, 0),
                TextWrapping = TextWrapping.Wrap,
                Foreground = isDiscounted ? new SolidColorBrush(Color.FromArgb(180, 255, 255, 255)) : Brushes.Gray,
                MaxHeight = 50
            };
            Grid.SetRow(compositionText, 1);
            mainGrid.Children.Add(compositionText);

            var imageContainer = new Grid { Margin = new Thickness(15, 5, 15, 5) };
            try
            {
                imageContainer.Children.Add(new Image
                {
                    Source = new BitmapImage(new Uri(product.ProductPhoto, UriKind.RelativeOrAbsolute)),
                    MaxHeight = 130,
                    MaxWidth = 200,
                    Stretch = Stretch.Uniform,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                });
            }
            catch { }
            Grid.SetRow(imageContainer, 2);
            Grid.SetRowSpan(imageContainer, 2);
            mainGrid.Children.Add(imageContainer);

            var removeBtn = new Button
            {
                Content = "Убрать",
                Margin = new Thickness(15, 5, 15, 5),
                Background = new SolidColorBrush(Colors.Orange),
                Foreground = Brushes.White,
                BorderThickness = new Thickness(0),
                Height = 30,
                Tag = product,
                HorizontalAlignment = HorizontalAlignment.Stretch
            };
            removeBtn.Click += ButtonRemove_Click;
            Grid.SetRow(removeBtn, 4);
            mainGrid.Children.Add(removeBtn);

            var priceGrid = new Grid { Margin = new Thickness(15, 0, 15, 12) };
            priceGrid.ColumnDefinitions.Add(new ColumnDefinition());
            priceGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            priceGrid.Children.Add(new TextBlock { Text = "Стоимость", VerticalAlignment = VerticalAlignment.Center, FontSize = 13, Foreground = isDiscounted ? Brushes.White : Brushes.Black });

            var priceBorder = new Border
            {
                Background = isDiscounted ? new SolidColorBrush(Color.FromArgb(80, 255, 255, 255)) : Brushes.Transparent,
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(8, 2, 8, 2),
                HorizontalAlignment = HorizontalAlignment.Right
            };
            priceBorder.Child = new TextBlock
            {
                Text = $"{product.Price:N2} ₽",
                Foreground = isDiscounted ? Brushes.White : new SolidColorBrush((Color)ColorConverter.ConvertFromString("#67BA80")),
                FontWeight = FontWeights.Bold,
                FontSize = 17
            };
            Grid.SetColumn(priceBorder, 1);
            priceGrid.Children.Add(priceBorder);

            Grid.SetRow(priceGrid, 5);
            mainGrid.Children.Add(priceGrid);

            border.Child = mainGrid;
            return border;
        }

        private void ButtonRemove_Click(object sender, RoutedEventArgs e)
        {
            var product = (sender as Button)?.Tag as Product;
            if (product != null)
            {
                cart.Remove(product);
                LoadCart();
            }
        }

        private void ButtonOrder_Click(object sender, RoutedEventArgs e)
        {
            if (!cart.Any())
            {
                MessageBox.Show("Корзина пуста!", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var address = TextBoxAddress.Text.Trim();
            if (string.IsNullOrWhiteSpace(address))
            {
                MessageBox.Show("Введите адрес доставки!", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (User.currentUser == null)
            {
                MessageBox.Show("Для оформления заказа необходимо авторизоваться!", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                var context = Entities.GetContext();
                var order = new Order
                {
                    AdressDelivery = address,
                    UserFIO = User.currentUser.id,
                    Login = User.currentUser.Login,
                    Role_Id = User.currentUser.Role_id,
                    Status_Id = 1,
                    OrderDate = DateTime.Now,
                    DeliveryDate = DateTime.Now.AddDays(7),
                    ProductName = string.Join(", ", cart.Select(p => p.ProductName)),
                    Type_Id = cart.FirstOrDefault()?.Product_id ?? 1,
                    Quantity = cart.Count,
                    PriceOrder = cart.Sum(p => p.Price),
                    LineTotal = cart.Sum(p => p.Price)
                };

                context.Order.Add(order);
                context.SaveChanges();

                cart.Clear();
                MessageBox.Show("Заказ успешно оформлен!", "Заказ оформлен", MessageBoxButton.OK, MessageBoxImage.Information);
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при оформлении заказа: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ButtonClear_Click(object sender, RoutedEventArgs e)
        {
            if (cart.Any() && MessageBox.Show("Очистить корзину?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                cart.Clear();
                LoadCart();
            }
        }
    }
}
