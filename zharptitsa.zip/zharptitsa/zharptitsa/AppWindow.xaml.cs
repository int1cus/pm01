using System;
using System.IO;
using System.Windows;
using zharptitsa.Pages;

namespace zharptitsa
{
    public partial class AppWindow : Window
    {
        public static string FrameTitle = "";

        public AppWindow()
        {
            InitializeComponent();
            MainFrame.Navigate(new MainPage());
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e) => e.Cancel = MessageBox.Show("Вы точно хотите выйти?", "Закрытие", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.No;

        private void ButtonBack_Click(object sender, RoutedEventArgs e)
        {
            if (MainFrame.Content is MainPage && User.currentUser != null)
            {
                User.currentUser = null;
                MainFrame.Navigate(new MainPage());
            }
            else if (MainFrame.CanGoBack)
            {
                MainFrame.GoBack();
            }
        }

        private void MainFrame_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            ButtonBack.IsEnabled = MainFrame.CanGoBack || (MainFrame.Content is MainPage && User.currentUser != null);
            TextBlockTitle.Text = FrameTitle;
            TextBlockName.Text = User.currentUser?.FullName ?? "";
        }
    }
}
